# Animating CSS-Only Hamburger Menu Icons

A collection of animating CSS-only hamburger menu icons. View demo [here](http://callmenick.com/_development/css-hamburger-menu-icons/).

## License

Licensed under the MIT license, http://www.opensource.org/licenses/mit-license.php

Copyright 2014, Call Me Nick

http://callmenick.com

## Live Demo

[View the live demo here](http://callmenick.com/_development/css-hamburger-menu-icons/).